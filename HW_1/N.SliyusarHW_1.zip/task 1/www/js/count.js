
let count = 7;

console.log("Значение:" + " " + count);
console.log("Квадрат этого значения:" + " " + count **2);
console.log("Куб этого значения:" + " " + count **3);