
let todayDegreesC = 25;
let todayTemperatureF = 73;

let cFormatF = todayDegreesC * 9 / 5 + 32;
console.log(todayDegreesC + "\u00B0" + "C" + " " + "равно" + " " + cFormatF + "\u00B0" + "F");

let fFormatC = Math.round((todayTemperatureF - 32) * 5 / 9);
console.log(todayTemperatureF + "\u00B0" + "F" + " " + "равно" + " " + fFormatC + "\u00B0" + "C");